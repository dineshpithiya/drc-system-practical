import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { take, map } from 'rxjs/operators';
import { ProductService } from "../services/product.service";

import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class productResolverService implements Resolve <Observable<any>>{

  constructor(private service: ProductService) { }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
    return this.service.get_product([]).pipe(
      take(1),
      map((data:any) => data.data)
    )
  }
}