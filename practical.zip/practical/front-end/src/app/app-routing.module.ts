import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { ImportComponent } from './pages/import/import.component';
import { ProductComponent } from './pages/product/product.component';
import { BodyComponent } from './pages//layout/body/body.component';

const routes: Routes = [
  {
    path: '',
    component: BodyComponent,
    canActivate: [],
    children: [
      {
        path: '',
        component: HomeComponent,
        pathMatch: 'full',
        canActivate: []
      },
      { 
        path: 'products' , 
        component: ProductComponent
      }
    ]
  },
  { 
    path: 'import' , 
    component: ImportComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
