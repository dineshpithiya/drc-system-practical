import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpToken } from './interceptors/http-token';
import { Loader } from './interceptors/loader';
import { exception } from './interceptors/exception';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
  ],
  providers: [
    { 
      provide: HTTP_INTERCEPTORS, 
      useClass: HttpToken, 
      multi: true 
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: Loader,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: exception,
      multi: true
    }
  ],
})
export class CoreModule { }
