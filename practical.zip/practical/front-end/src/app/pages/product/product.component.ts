import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FacadeService } from "../../services/facade.service";
import { NgbPaginationConfig } from "@ng-bootstrap/ng-bootstrap";
import { Options, ChangeContext } from "ng5-slider";
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  page = 1;
  maxSize:any= 0;
  pageSize:any =0;
  collectionSize:any=0;
  products:any=[];
  pageNumber:any=1;
  location:any=[];
  location_filter:any="";
  hdd_filter:any="";
  storage:any=[];
  value: number = 100;

  options: Options = {
    showTicksValues: true,
    stepsArray: [
      {value: 0, legend: 'GB'},
      {value: 250, legend: 'GB'},
      {value: 500, legend: 'GB'},
      {value: 1, legend: 'TB'},
      {value: 2, legend: 'TB'},
      {value: 3, legend: 'TB'},
      {value: 4, legend: 'TB'},
      {value: 8, legend: 'TB'},
      {value: 12, legend: 'TB'},
      {value: 24, legend: 'TB'},
      {value: 48, legend: 'TB'}
    ]
  };

  constructor(
    private service : FacadeService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    config: NgbPaginationConfig,
    private router: Router){
      config.size = "sm";
      config.boundaryLinks = true;
    }
  ngOnInit(): void {
    this.show();
    this.getFilter();
  }
  getFilter(){
    this.service.get_location().subscribe((data:any)=>{
      this.location=data.data;
    })
  }
  show(){
    this.service.get_product({
      page:this.pageNumber,
      location:this.location_filter,
      hdd_type:this.hdd_filter,
      storage:this.storage}).subscribe((data: any) => {
      this.products=data.data;
      this.pageSize=data.paginator.perPage;
      this.maxSize=data.paginator.perPage;
      this.collectionSize=data.paginator.total;
    });
  }
  pageChange(page:number){
    this.pageNumber=page;
    this.show();
  }
  locationChange(e:any){
    this.location_filter=e.target.value;
    this.show();
  }
  hddChange(e:any){
    this.hdd_filter=e.target.value;
    this.show();
  }
  onUserChange(changeContext: ChangeContext): void {
    this.storage=[0];
    this.storage.push(changeContext.value)
    this.show();
  }
  reset(){
    if(confirm("Are you sure you wan't to reset all filter")){
      this.pageNumber=1;
      this.location_filter="";
      this.hdd_filter="";
      this.storage="";
      this.show();
    }
    
  }
}
