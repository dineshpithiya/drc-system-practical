import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FacadeService } from "../../services/facade.service";
@Component({
  selector: 'app-import',
  templateUrl: './import.component.html',
  styleUrls: ['./import.component.css']
})
export class ImportComponent implements OnInit {
  submitForm: FormGroup;
  submitted = false;
  returnUrl: string;
  filedata: any;
  constructor(
    private service : FacadeService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router){ 

    }
  ngOnInit(): void {
    this.submitForm = this.formBuilder.group({
      product_file: ['', [Validators.required]]
    });
  }
  get f() { return this.submitForm.controls; }
  fileProgress(fileInput: any) {
    let preview = <File>fileInput.target.files[0];
    this.filedata = fileInput.target.files[0];
  }
  onSubmit() {
    this.submitted = true;
    if (this.submitForm.invalid) {
      return;
    }
    var myFormData = new FormData();
    myFormData.append('product_file', this.filedata);
    this.service.import_product(myFormData).subscribe((data:any)=>{
      this.submitted = false;
      this.submitForm.reset();
      this.router.navigate(['/products']);
    })
  }  
}
