import { Injectable, Injector } from "@angular/core";
import { ProductService } from "./product.service";
import swal from "sweetalert2";
import { NgxSpinnerService } from "ngx-spinner";
import { environment as env } from "../../environments/environment";
@Injectable({
  providedIn: "root"
})
export class FacadeService {
  env:any=env;
  private _productService: ProductService;
  constructor(private injector: Injector,
    private spinner: NgxSpinnerService) {}
  
  public get productService(): ProductService {
    if (!this._productService) {
      this._productService = this.injector.get(ProductService);
    }
    return this._productService;
  }
  import_product(data:any){
    return this.productService.import_product(data);
  }
  get_product(data:any){
    return this.productService.get_product(data);
  }
  get_location(){
    return this.productService.get_location();
  }
  swal_success(msg: any) {
    swal.fire("", msg, "success");
  }
  swal_fail(msg: any) {
    swal.fire({
      icon: "error",
      text: msg
    });
  }
  show(){
    this.spinner.show();
  }
  hide(){
    this.spinner.hide();
  }
}