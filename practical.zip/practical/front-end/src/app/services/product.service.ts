import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  constructor(public http: HttpClient) { }
  
  import_product(data:any){
    return this.http.post('products',data);
  }
  get_product(data:any){
    return this.http.post('get-products',data);
  }
  get_location(){
    return this.http.get('get-location');
  }
}
