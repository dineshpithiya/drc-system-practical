import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { FacadeService } from "../services/facade.service";
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class exception implements HttpInterceptor {
  constructor(
    private _router: Router,
    private service:FacadeService) { }
  intercept(request: HttpRequest<any>, next: HttpHandler): any {
    return next.handle(request).pipe(
      tap(
        event => { },
        error => {
          if (error instanceof HttpErrorResponse) {
            this.code(error.status,error);
          }
        }
      ));
  }
  code(status:any,msg:any) 
  {
    switch (status) {
      case 0:
        this.service.swal_fail("Sonthing wen't wrong at server side");
        break;
      case 500:
        this.service.swal_fail("Sonthing wen't wrong at server side");
        break;
      case 400:
        this.service.swal_fail(msg.error.msg);
        break;
      case 401:
        let _msg=msg.error.msg?msg.error.msg:msg.statusText;
        this.service.swal_fail(_msg);
        break;
      case 403:
        this.service.swal_fail(msg.error.msg);
        break;    
      case 404:
        this.service.swal_fail(msg.error.msg);
        break;
        case 409:
          this.service.swal_fail(msg.error.msg);
          break;  
      case 204:
        this.service.swal_fail("No Content");
        location.reload();
        break; 
      case -1: // request time out
      this.service.swal_fail("request time out");
        break;
      default:
        console.log(msg);
    }
  }
}