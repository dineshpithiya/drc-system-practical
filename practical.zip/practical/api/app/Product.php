<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
	public $table = 'products';
    public $fillable = [
        'model',
        'ram_size',
        'ram_type',
        'hdd',
        'hdd_size',
        'hdd_type',
        'location',
        'price',
        'price_currency',
        'created_at',
        'updated_at'
    ];
    public static $rules = [
        'import'=>[
            'product_file'=>'required'
        ]
    ];
}
