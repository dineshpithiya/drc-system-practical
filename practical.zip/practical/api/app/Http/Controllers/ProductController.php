<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;
use Helper;
use Validator;
use Carbon\Carbon;
use SimpleXLSX;
use DB;
class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query=Product::from("products")
            ->when($request->input('location'), function ($query, $val) {
                return $query->Where(["location"=>$val]);
            })
            ->when($request->input('hdd_type'), function ($query, $val) {
                return $query->Where(["hdd_type"=>$val]);
            })
            ->when($request->input('storage'), function ($query, $val) {
                return $query->where(function ($query) use ($val) {
                    $query->orWhereBetween('hdd_size', [$val[0], (int)$val[1]]);
                });
            })
            ->when($request->input('ram'), function ($query, $val) {
                return $query->WhereIn("ram_size",$val);
            })->paginate(10);
            $pagination = [
                "current_page"=>$query->toArray()["current_page"],
                "first_page_url"=>$query->toArray()["first_page_url"],
                "from"=>$query->toArray()["from"],
                "last_page"=>$query->toArray()["last_page"],
                "per_page"=>$query->toArray()["per_page"],
                "to"=>$query->toArray()["to"],
                "total"=>$query->toArray()["total"],
                "data"=>$query->toArray()["data"]
            ];    
        return Helper::success($pagination,"success",200);
    }

    public function location()
    {
        $query=Product::select('location')
            ->distinct()->get();
        return Helper::success($query,"success",200);   
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $error=Helper::validator($request,Product::$rules['import']);
        if($error) return $error;

        $data=[];
        if($xlsx = SimpleXLSX::parse($_FILES['product_file']['tmp_name'])) 
        {
            $dim = $xlsx->dimension();
            $cols = $dim[0];
            $data=$xlsx->rows();
            $product_rows=[];
            if(sizeof($data)>0){
                $column_name=array_slice($data[0], 0, 5);
                unset($data[0]);
                foreach ($data as $key => $value) {
                    $ram = explode("GB", strtoupper($value[1]));
                    $ram_size =$ram[0];
                    $ram_type =$ram[1];
                    $hdd = preg_split('/(X|TB|GB)/',strtoupper($value[2]),-1, PREG_SPLIT_NO_EMPTY);
                    $hdd_size = $hdd[1];
                    $hdd_type = preg_replace('/[0-9]+/', '', $hdd[2]);
                    if (str_contains(strtoupper($value[2]), 'TB')) { 
                        $hdd_size=$hdd_size*1000;
                    }
                    
                    $hdd=strtoupper($value[2]);
                    $price=preg_split('/(€|$)/',strtoupper($value[4]),-1, PREG_SPLIT_NO_EMPTY);
                    $price_currency=str_replace('.', '', preg_replace('/[0-9]+/', '',$value[4]));
                    $value=array_slice($value, 0, 5);
                    $product_rows[]=[
                        'model'=>$value[0],
                        'ram_size'=>$ram_size,
                        'ram_type'=>$ram_type,
                        'hdd'=>$hdd,
                        'hdd_size'=>$hdd_size,
                        'hdd_type'=>$hdd_type,
                        'location'=>$value[3],
                        'price'=>$price[0],
                        'price_currency'=>$price_currency,
                    ];
                }
                if(sizeof($product_rows)>0){
                    DB::table('products')->insert($product_rows);
                    return Helper::success([],"Imported file successfully.");
                }else{
                    return Helper::fail("No record imported.");
                }
            }
            else{
                return Helper::fail('Invalid file.');
            }
        } 
        else {
            return Helper::fail(SimpleXLSX::parseError());
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }
}
