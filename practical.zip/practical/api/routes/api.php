<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

$router->get('/', function () use ($router) {
    return "Welcome to API Route";
});
$router->get('/clear-all-cache', function () use ($router) {
    Artisan::call('cache:clear');
    Artisan::call('route:clear');
    Artisan::call('view:clear');
    Artisan::call('config:cache');
    return 'Cache value cleared';
});
Route::get('get-location', 'ProductController@location');
Route::post('get-products', 'ProductController@index');
Route::post('products','ProductController@create');
